```python
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional
from pydantic import BaseModel, Field

# Event Status Enum Definition
class EventStatus(Enum):
    PLANNED = "planned"
    ONGOING = "ongoing"
    COMPLETED = "completed"

# Event Model Definition
class Event(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    status: EventStatus
    start_date: datetime
    end_date: Optional[datetime] = None

# Participant Model Definition
class Participant(BaseModel):
    id: str
    name: str
    email: str
    event_id: str

# Response Model for Event Creation
class EventCreationResponse(BaseModel):
    id: str
    status: str

# Response Model for Participant Creation
class ParticipantCreationResponse(BaseModel):
    id: str
    event_id: str
    status: str
```