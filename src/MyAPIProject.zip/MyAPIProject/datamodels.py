```python
from datetime import datetime
from enum import Enum
from typing import Optional, List
from pydantic import BaseModel, EmailStr

class EventType(str, Enum):
    CONFERENCE = "Conference"
    SEMINAR = "Seminar"
    WORKSHOP = "Workshop"
    WEBINAR = "Webinar"

class EventStatus(str, Enum):
    PLANNING = "Planning"
    UPCOMING = "Upcoming"
    ONGOING = "Ongoing"
    COMPLETED = "Completed"
    CANCELLED = "Cancelled"

class TicketType(str, Enum):
    FREE = "Free"
    PAID = "Paid"
    DONATION = "Donation"

class Address(BaseModel):
    street: str
    city: str
    state: str
    country: str
    postal_code: str

class Ticket(BaseModel):
    type: TicketType
    price: Optional[float] = 0.0
    quantity_available: int

class Event(BaseModel):
    id: Optional[int]
    name: str
    organizer_email: EmailStr
    event_type: EventType
    status: EventStatus
    start_date: datetime
    end_date: datetime
    venue: str
    address: Address
    description: Optional[str] = None
    tickets: List[Ticket]

class User(BaseModel):
    id: Optional[int]
    name: str
    email: EmailStr
    registered_events: List[int] = []
```