from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional
from pydantic import BaseModel, Field

class EventStatus(Enum):
    UPCOMING = "upcoming"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class Event(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    start_time: datetime
    end_time: datetime
    location: str
    capacity: int
    status: EventStatus = Field(default=EventStatus.UPCOMING)
    attendees: List[str] = []
    created_at: datetime
    updated_at: datetime