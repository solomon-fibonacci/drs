from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional
from pydantic import BaseModel, Field

class EventStatus(Enum):
    SCHEDULED = "scheduled"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class EventType(Enum):
    CONFERENCE = "conference"
    MEETUP = "meetup"
    WORKSHOP = "workshop"
    OTHER = "other"

class Location(BaseModel):
    address: str
    city: str
    state: str
    country: str

class Event(BaseModel):
    id: str
    name: str
    description: str
    start_date: datetime = Field(default_factory=datetime.now)
    end_date: datetime = Field(default_factory=datetime.now)
    location: Location
    event_type: EventType = EventType.OTHER
    status: EventStatus = EventStatus.SCHEDULED
    capacity: int
    attendees: List[str] = []

class Attendee(BaseModel):
    id: str
    name: str
    email: str
    phone_number: Optional[str] = None
    events_attended: List[str] = []