```python
from typing import Dict, List, Union
from models import Event, User

# Assuming there's a simple in-memory database for demo purposes.
db_events: Dict[int, Event] = {}
db_users: Dict[int, User] = {}

event_id_counter = 1
user_id_counter = 1

# Event CRUD operations
def create_event(event_data: Event) -> Event:
    global event_id_counter
    event_data.id = event_id_counter
    db_events[event_id_counter] = event_data
    event_id_counter += 1
    return event_data

def get_event(event_id: int) -> Union[Event, None]:
    return db_events.get(event_id)

def update_event(event_id: int, update_data: Event) -> Union[Event, None]:
    if event_id in db_events:
        updated_event = db_events[event_id].copy(update=update_data.dict(exclude_unset=True))
        db_events[event_id] = updated_event
        return updated_event
    return None

def delete_event(event_id: int) -> bool:
    if event_id in db_events:
        del db_events[event_id]
        return True
    return False

def list_events() -> List[Event]:
    return list(db_events.values())

# User CRUD operations
def create_user(user_data: User) -> User:
    global user_id_counter
    user_data.id = user_id_counter
    db_users[user_id_counter] = user_data
    user_id_counter += 1
    return user_data

def get_user(user_id: int) -> Union[User, None]:
    return db_users.get(user_id)

def update_user(user_id: int, update_data: User) -> Union[User, None]:
    if user_id in db_users:
        updated_user = db_users[user_id].copy(update=update_data.dict(exclude_unset=True))
        db_users[user_id] = updated_user
        return updated_user
    return None

def delete_user(user_id: int) -> bool:
    if user_id in db_users:
        del db_users[user_id]
        return True
    return False

def list_users() -> List[User]:
    return list(db_users.values())

# Additional functionality: User registration to Event
def register_user_to_event(user_id: int, event_id: int) -> bool:
    user = get_user(user_id)
    event = get_event(event_id)
    if user and event:
        if event_id not in user.registered_events:
            user.registered_events.append(event_id)
            return True
    return False
```