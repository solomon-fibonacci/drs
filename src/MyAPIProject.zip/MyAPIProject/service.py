from typing import List
from models import Event
from database import DatabaseSession

class EventService:
    @staticmethod
    async def create_event(event: Event) -> Event:
        # Implementation for creating an event
        async with DatabaseSession() as db:
            db.add(event)
            await db.commit()
            await db.refresh(event)
        return event

    @staticmethod
    async def get_events() -> List[Event]:
        # Implementation for getting all events
        async with DatabaseSession() as db:
            events = db.query(Event).all()
        return events

    @staticmethod
    async def get_event_by_id(event_id: str) -> Event:
        # Implementation for getting a specific event by ID
        async with DatabaseSession() as db:
            event = db.query(Event).get(event_id)
        return event

    @staticmethod
    async def update_event(event_id: str, event_update: Event) -> Event:
        # Implementation for updating an event
        async with DatabaseSession() as db:
            event = db.query(Event).get(event_id)
            event.name = event_update.name
            event.description = event_update.description
            event.start_date = event_update.start_date
            event.end_date = event_update.end_date
            event.location = event_update.location
            event.event_type = event_update.event_type
            event.status = event_update.status
            event.capacity = event_update.capacity
            await db.commit()
            await db.refresh(event)
        return event

    @staticmethod
    async def delete_event(event_id: str) -> None:
        # Implementation for deleting an event
        async with DatabaseSession() as db:
            event = db.query(Event).get(event_id)
            db.delete(event)
            await db.commit()