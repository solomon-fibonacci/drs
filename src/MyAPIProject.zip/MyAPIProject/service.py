from typing import List
from models import Event, Participant
from database import DatabaseSession

class EventService:
    @staticmethod
    async def create_event(event: Event) -> EventCreationResponse:
        async with DatabaseSession() as session:
            session.add(event)
            await session.commit()
        return EventCreationResponse(id=event.id, status="created")

    @staticmethod
    async def get_events() -> List[Event]:
        async with DatabaseSession() as session:
            events = await session.execute(session.query(Event).all())
        return events.scalars().all()

    @staticmethod
    async def get_event_by_id(event_id: str) -> Event:
        async with DatabaseSession() as session:
            event = await session.get(Event, event_id)
        return event

    @staticmethod
    async def update_event(event_id: str, event_update: Event) -> Event:
        async with DatabaseSession() as session:
            event = await session.get(Event, event_id)
            if event:
                for var, value in vars(event_update).items():
                    setattr(event, var, value) if value else None
                await session.commit()
        return event

    @staticmethod
    async def delete_event(event_id: str) -> None:
        async with DatabaseSession() as session:
            event = await session.get(Event, event_id)
            if event:
                await session.delete(event)
                await session.commit()

class ParticipantService:
    @staticmethod
    async def create_participant(participant: Participant) -> ParticipantCreationResponse:
        async with DatabaseSession() as session:
            session.add(participant)
            await session.commit()
        return ParticipantCreationResponse(id=participant.id, event_id=participant.event_id, status="created")

    @staticmethod
    async def get_participants() -> List[Participant]:
        async with DatabaseSession() as session:
            participants = await session.execute(session.query(Participant).all())
        return participants.scalars().all()

    @staticmethod
    async def get_participant_by_id(participant_id: str) -> Participant:
        async with DatabaseSession() as session:
            participant = await session.get(Participant, participant_id)
        return participant

    @staticmethod
    async def update_participant(participant_id: str, participant_update: Participant) -> Participant:
        async with DatabaseSession() as session:
            participant = await session.get(Participant, participant_id)
            if participant:
                for var, value in vars(participant_update).items():
                    setattr(participant, var, value) if value else None
                await session.commit()
        return participant

    @staticmethod
    async def delete_participant(participant_id: str) -> None:
        async with DatabaseSession() as session:
            participant = await session.get(Participant, participant_id)
            if participant:
                await session.delete(participant)
                await session.commit()