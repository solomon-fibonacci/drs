from fastapi import APIRouter, HTTPException, Body, Depends, status
from fastapi.encoders import jsonable_encoder
from typing import List
from .datamodels import Event, Attendee

router = APIRouter()

@router.get("/events", response_model=List[Event], status_code=status.HTTP_200_OK)
async def get_events():
    events = await Event.all()
    return events

@router.post("/events", response_model=Event, status_code=status.HTTP_201_CREATED)
async def create_event(event: Event = Body(...)):
    new_event = await Event.create(event)
    return new_event

@router.put("/events/{event_id}", response_model=Event, status_code=status.HTTP_200_OK)
async def update_event(event_id: str, event: Event = Body(...)):
    event_to_update = await Event.get(event_id)
    if not event_to_update:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    updated_event = await event_to_update.update(event)
    return updated_event

@router.delete("/events/{event_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_event(event_id: str):
    event_to_delete = await Event.get(event_id)
    if not event_to_delete:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    await event_to_delete.delete()
    return {"message": "Event deleted successfully"}

@router.get("/events/{event_id}/attendees", response_model=List[Attendee], status_code=status.HTTP_200_OK)
async def get_attendees(event_id: str):
    event = await Event.get(event_id)
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    attendees = await Attendee.get_by_event_id(event_id)
    return attendees

@router.post("/events/{event_id}/attendees", response_model=Attendee, status_code=status.HTTP_201_CREATED)
async def add_attendee(event_id: str, attendee: Attendee = Body(...)):
    event = await Event.get(event_id)
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    new_attendee = await Attendee.create(attendee)
    event.attendees.append(new_attendee.id)
    await event.update(event)
    return new_attendee

@router.put("/events/{event_id}/attendees/{attendee_id}", response_model=Attendee, status_code=status.HTTP_200_OK)
async def update_attendee(event_id: str, attendee_id: str, attendee: Attendee = Body(...)):
    attendee_to_update = await Attendee.get(attendee_id)
    if not attendee_to_update:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    updated_attendee = await attendee_to_update.update(attendee)
    return updated_attendee

@router.delete("/events/{event_id}/attendees/{attendee_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_attendee(event_id: str, attendee_id: str):
    attendee = await Attendee.get(attendee_id)
    if not attendee:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    await attendee.delete()
    return {"message": "Attendee deleted successfully"}