from fastapi import APIRouter, HTTPException, status
from typing import List
from .datamodels import Event

router = APIRouter()

@router.get("/events", response_model=List[Event], status_code=status.HTTP_200_OK)
async def read_events():
    return await Event.all().prefetch_related("attendees").order_by("name").all()

@router.post("/events", response_model=Event, status_code=status.HTTP_201_CREATED)
async def create_event(event: Event):
    await event.save()
    return await event.fetch()

# Additional routes for getting a specific event by ID, updating an event, and deleting an event would be added here.