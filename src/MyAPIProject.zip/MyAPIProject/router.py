```python
from fastapi import APIRouter, HTTPException, status, Body
from typing import List
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field

class EventStatus(Enum):
    PLANNED = "planned"
    ONGOING = "ongoing"
    COMPLETED = "completed"

class Event(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    status: EventStatus
    start_date: datetime
    end_date: Optional[datetime] = None

class Participant(BaseModel):
    id: str
    name: str
    email: str
    event_id: str

class EventCreationResponse(BaseModel):
    id: str
    status: str

class ParticipantCreationResponse(BaseModel):
    id: str
    event_id: str
    status: str

router = APIRouter()

@router.get("/events", response_model=List[Event], status_code=status.HTTP_200_OK)
async def read_events():
    # Dummy data for illustration
    events = [
        Event(id="1", name="Tech Conference", description="Annual Tech Conference", status=EventStatus.PLANNED, start_date=datetime.now()),
        Event(id="2", name="Music Festival", description="Summer Music Festival", status=EventStatus.ONGOING, start_date=datetime.now())
    ]
    return events

@router.post("/events", response_model=EventCreationResponse, status_code=status.HTTP_201_CREATED)
async def create_event(event: Event):
    # Dummy implementation
    return EventCreationResponse(id=event.id, status="created")

@router.get("/events/{event_id}", response_model=Event, status_code=status.HTTP_200_OK)
async def read_event(event_id: str):
    # Dummy data for illustration
    event = Event(id=event_id, name="Tech Conference", description="Annual Tech Conference", status=EventStatus.PLANNED, start_date=datetime.now())
    return event

@router.put("/events/{event_id}", response_model=Event, status_code=status.HTTP_200_OK)
async def update_event(event_id: str, event: Event):
    # Dummy implementation for illustration
    event.id = event_id
    return event

@router.delete("/events/{event_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_event(event_id: str):
    # Dummy implementation for illustration
    pass

@router.post("/participants", response_model=ParticipantCreationResponse, status_code=status.HTTP_201_CREATED)
async def create_participant(participant: Participant):
    # Dummy implementation
    return ParticipantCreationResponse(id=participant.id, event_id=participant.event_id, status="added")

@router.get("/participants/{participant_id}", response_model=Participant, status_code=status.HTTP_200_OK)
async def read_participant(participant_id: str):
    # Dummy data for illustration
    participant = Participant(id=participant_id, name="John Doe", email="john@example.com", event_id="1")
    return participant
```