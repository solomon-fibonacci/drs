```python
from fastapi import APIRouter, HTTPException, status
from typing import List
from pydantic import EmailStr
from datetime import datetime
from uuid import uuid4, UUID

# Importing previously defined models
from models import Event, Address, Ticket, EventType, EventStatus, TicketType, User

router = APIRouter()

db_events: List[Event] = []
db_users: List[User] = []

# Event Routes
@router.post("/events/", response_model=Event, status_code=status.HTTP_201_CREATED)
def create_event(event: Event):
    event.id = len(db_events) + 1  # Simple unique identifier
    db_events.append(event)
    return event

@router.get("/events/", response_model=List[Event])
def read_all_events():
    return db_events

@router.get("/events/{event_id}", response_model=Event)
def read_event(event_id: int):
    for event in db_events:
        if event.id == event_id:
            return event
    raise HTTPException(status_code=404, detail="Event not found")

@router.put("/events/{event_id}", response_model=Event)
def update_event(event_id: int, updated_event: Event):
    for idx, event in enumerate(db_events):
        if event.id == event_id:
            updated_event.id = event_id
            db_events[idx] = updated_event
            return updated_event
    raise HTTPException(status_code=404, detail="Event not found")

@router.delete("/events/{event_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_event(event_id: int):
    for idx, event in enumerate(db_events):
        if event.id == event_id:
            del db_events[idx]
            return
    raise HTTPException(status_code=404, detail="Event not found")

# User Routes
@router.post("/users/", response_model=User, status_code=status.HTTP_201_CREATED)
def create_user(user: User):
    user.id = len(db_users) + 1  # Simple unique identifier
    db_users.append(user)
    return user

@router.get("/users/", response_model=List[User])
def read_all_users():
    return db_users

@router.get("/users/{user_id}", response_model=User)
def read_user(user_id: int):
    for user in db_users:
        if user.id == user_id:
            return user
    raise HTTPException(status_code=404, detail="User not found")

@router.put("/users/{user_id}", response_model=User)
def update_user(user_id: int, updated_user: User):
    for idx, user in enumerate(db_users):
        if user.id == user_id:
            updated_user.id = user_id
            db_users[idx] = updated_user
            return updated_user
    raise HTTPException(status_code=404, detail="User not found")

@router.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: int):
    for idx, user in enumerate(db_users):
        if user.id == user_id:
            del db_users[idx]
            return
    raise HTTPException(status_code=404, detail="User not found")
```