from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from events.router import events_router

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(events_router, prefix="/events", tags=["events"])